-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2018 at 09:12 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `store`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_account`
--

CREATE TABLE `bank_account` (
  `account` int(255) NOT NULL,
  `balance` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_account`
--

INSERT INTO `bank_account` (`account`, `balance`) VALUES
(1, 7941237),
(3, 42390423),
(4, 4421949),
(5, 1000000),
(7, 2103003),
(8, 212120021),
(9, 20002102),
(10, 309932),
(324565, 254390123);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Cat_id` int(255) NOT NULL,
  `Cat_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Cat_id`, `Cat_name`) VALUES
(1, 'Shirts'),
(2, 'Watches'),
(3, 'Camera');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `Image` text NOT NULL,
  `Description` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`, `Image`, `Description`) VALUES
(1, 'Canon_EOS', 40000, 'cannon_eos.jpg', ''),
(2, 'Sony DSLR', 40000, 'cannon_eos.jpg', ''),
(3, 'Sony DSLR', 50000, 'sony_dslr.jpeg', ''),
(4, 'Olympus DSLR', 80000, 'olympus.jpg', ''),
(5, 'Titan Model #301', 13000, 'titan301.jpg', ''),
(6, 'Titan Model #201', 3000, 'titan201.jpg', ''),
(7, 'HMT Milan', 8000, 'hmt.jpg', ''),
(8, 'Favre Lueba #111', 18000, 'favreleuba.jpg', ''),
(9, 'Raymond', 1500, 'Raymond.jpg', ''),
(10, 'Charles', 1000, 'charles.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `account` int(255) DEFAULT '34'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `contact`, `city`, `address`, `account`) VALUES
(1, 'Sajal', 'sajal.rahman1997@gmail.com', '57f231b1ec41dc6641270cb09a56f897', '8899889988', 'Rajshahi', '100 palace colony, Rajshahi', 1),
(3, 'Shyam', 'shyam@xyz.com', '57f231b1ec41dc6641270cb09a56f897', '8899889990', 'Bangalore', '100 palace colony, Bangalore', 2),
(4, 'Tayef Rahman', 'artayefrahman@gmail.com', '14e1b600b1fd579f47433b88e8d85291', '01521223374', 'Dhaka', 'CUET', 3),
(5, 'M. A. Muhaimin Sakib', 's4k1b13@gmail.com', 'd94935b6e3c7b9ed947c767f86434a45', '01716303505', 'Cumilla', 'CUET', 4),
(7, 'Ruposh', 'hasanabid@gmail.com', '224cf2b695a5e8ecaecfb9015161fa4b', '0123456789', 'Rajshahi', 'CUET', 5),
(8, 'Tamim', 'tamimrahman@gmail.com', '14e1b600b1fd579f47433b88e8d85291', '01521464648', 'Dhaka', 'CUET', 6),
(9, 'Tanvir', 'tanvir@gmail.com', '14e1b600b1fd579f47433b88e8d85291', '0123456789', 'Dhaka', 'dsfsdbgsdf', 7),
(10, '', '', '74be16979710d4c4e7c6647856088456', '', '', '', 34),
(11, 'Hasan Hasan', 'hasanhasan@gmail.com', '1b2b1c1b9a4f61971e9332ba3772cdd8', '0198921223', 'Chittagong', 'Cuet BB Hall', 10);

-- --------------------------------------------------------

--
-- Table structure for table `users_items`
--

CREATE TABLE `users_items` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `status` enum('Added to cart','Confirmed') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_account`
--
ALTER TABLE `bank_account`
  ADD PRIMARY KEY (`account`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Cat_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_items`
--
ALTER TABLE `users_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`,`item_id`),
  ADD KEY `item_id` (`item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Cat_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users_items`
--
ALTER TABLE `users_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users_items`
--
ALTER TABLE `users_items`
  ADD CONSTRAINT `users_items_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `users_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
